<?php include 'includes/connection.php';?>
<?php include 'includes/header.php';?>
<?php include 'includes/navbar.php';?>

<?php
$message = '';

if (isset($_POST['recover'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $query = "SELECT username FROM users WHERE email = '$email'";
        $run = mysqli_query($conn, $query) or die(mysqli_error($conn));
        
        if (mysqli_num_rows($run) > 0) {
            $row = mysqli_fetch_assoc($run);
            $userName = $row['username'];

            function generateRandomString($length = 5) {
                return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
            }
 
            $token_tmp = generateRandomString();
            $token = md5($token_tmp);
            $url = $_SERVER['REQUEST_URI'];
            $parts = explode('/', $url);
            $dir = $_SERVER['SERVER_NAME'] . '/';
            for ($i = 0; $i < count($parts) - 1; $i++) {
                $dir .= $parts[$i] . "/";
            }
            
            $token = bin2hex(random_bytes(50));

            require 'PHPMailer/PHPMailerAutoload.php';

            $mail = new PHPMailer;

            $mail->isSMTP();                            // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                     // Enable SMTP authentication
            $mail->Username = 'gdarshankumar2003@gmail.com';          // SMTP username
            $mail->Password = 'tpdm ixzd wzfl kavu';    // SMTP password
            $mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                          // TCP port to connect to

            $mail->setFrom('collegenotesgallery@gmail.com', 'Admin');
            $mail->addReplyTo('collegenotesgallery@gmail.com', 'Admin');
            $mail->addAddress($email);

            $mail->isHTML(true);  // Set email format to HTML
            $bodyContent = "<h1>Hello $userName,</h1>";
            $bodyContent .= '<p>Click the following link to recover your password:</p>';
            $bodyContent .= '<a href="http://' . $dir . 'verifytoken.php?token=' . $token . '">Recover Password</a>';

            $mail->Subject = 'Email from collegenotesgallery';
            $mail->Body    = $bodyContent;

            $query2 = "UPDATE users SET token = '$token' WHERE email = '$email'";
            $run = mysqli_query($conn, $query2) or die(mysqli_error($conn));
            $count = mysqli_affected_rows($conn);
            if ($mail->send() && ($count > 0)) {
                $message = "<center><font color='green'>Email with recover password link has been sent</font></center>";
            } else {
                $message = "<center><font color='red'>Message could not be sent.</font></center>";
                $message .= "<center><font color='red'>Mailer Error: " . $mail->ErrorInfo . "</font></center>";
            }
        } else {
            $message = "<center><font color='red'>Entered email does not match any record</font></center>";
        }
    } else {
        $message = "<center><font color='red'>Invalid email type</font></center>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recover Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: url("images/login page.jpg") no-repeat center center fixed;
            background-size: cover;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.8); /* semi-transparent white background */
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        .login-card h1 {
            margin-bottom: 20px;
        }
        .login-card input[type="text"], .login-card input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-help {
            margin-top: 20px;
        }
        .login-help a {
            text-decoration: none;
            color: #007BFF;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>Recover Password</h1><br>
        <form action="" method="POST">
            <input type="text" name="email" placeholder="Enter your Email" required="">
            <input type="submit" name="recover" class="login login-submit" value="Send">
        </form>
        <?php
        if (!empty($message)) {
            echo $message;
        }
        ?>
        <div class="login-help">
            <a href="signup.php">Register</a> • <a href="login.php">Login</a>
        </div>
    </div>

    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
</body>
</html>
