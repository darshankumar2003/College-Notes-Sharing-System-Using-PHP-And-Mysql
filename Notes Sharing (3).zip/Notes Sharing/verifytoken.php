<?php include ('includes/connection.php'); ?>
<?php include 'includes/header.php';?>
<?php include 'includes/navbar.php';?>

<?php
if (!empty($_GET['token'])) {	
    $token = mysqli_real_escape_string($conn , $_GET['token']);
    $query = "SELECT token FROM users WHERE token = '$token'";
    $run = mysqli_query($conn , $query) or die(mysqli_error($conn));
    if (mysqli_num_rows($run) > 0) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Change Password</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                    background: url("images/login page.jpg") no-repeat center center fixed;
                    background-size: cover;
                }
                .login-card {
                    background: rgba(255, 255, 255, 0.8); /* semi-transparent white background */
                    padding: 40px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                    max-width: 400px;
                    width: 100%;
                    text-align: center;
                }
                .login-card h1 {
                    margin-bottom: 20px;
                }
                .login-card input[type="password"], .login-card input[type="submit"] {
                    width: 100%;
                    padding: 10px;
                    margin: 10px 0;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                }
            </style>
        </head>
        <body>
            <div class="login-card">
                <h1>Change Password</h1><br>
                <form action="" method="POST">
                    <input type="password" name="password" placeholder="Enter New Password" required="">
                    <input type="password" name="repassword" placeholder="Confirm New Password" required="">
                    <input type="submit" name="change" class="login login-submit" value="submit">
                </form>
                <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
                <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>
                <?php 
                if (isset($_POST['change'])) {
                    $password = mysqli_real_escape_string($conn , $_POST['password']);
                    $repassword = mysqli_real_escape_string($conn , $_POST['repassword']);
                    if (strlen($password) < 6 ) {
                        echo "<center> <font color = 'red' > Password should be at least 6 characters long!</font><center>";
                    } 
                    else if ($password == $repassword) {
                        $newpassword = password_hash("$password" , PASSWORD_DEFAULT);
                        $query1 = "UPDATE users SET token = '' , password = '$newpassword' WHERE token = '$token'";
                        $run = mysqli_query($conn , $query1) or die(mysqli_error($conn));
                        if (mysqli_affected_rows($conn) > 0) {
                            echo "<center> <font color = 'green' > Password Changed Successfully </font><center>" . " " . "<a href='login.php'>login</a>";
                        } else {
                            echo "<center> <font color = 'red' > Error Occurred!</font><center>";
                        }
                    } else {
                        echo "<center> <font color = 'red' > Passwords do not match</font><center>";
                    }
                }
                ?>
            </div>
        </body>
        </html>
        <?php 
    } else {
        echo "Something went wrong. <a href=recoverpassword.php> Try again </a>";
    }
} else {
    header("location: index.php");
}
?>
