 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: brown;">COPYRIGHT</i> 2018-19 <b >Online Notes Sharing <a href="https://projectworlds.in">Projectworlds</a></b></p>
                </div>
            </div>
   </footer>