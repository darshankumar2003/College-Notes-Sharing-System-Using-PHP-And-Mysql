<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background-color: #007bff;">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php" style="color: #ffffff; text-align: center; width: 100%; display: block;">G.F.G.C Sorab-BCA-Notes-Gallery</a>
    </div>

    <ul class="nav navbar-right top-nav">
        <?php if($_SESSION['role'] !== 'admin') { ?> 
        <li><a href="./uploadnote.php" style="color: #ffffff;">UPLOAD</a></li> 
        <?php } ?>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color: #ffffff;">
            <i class="fa fa-user"></i> <span class="session-name"><?php echo $_SESSION['name']; ?></span> <b class="caret"></b>

            </a>
            <ul class="dropdown-menu">
                <li><a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>"><i class="fa fa-fw fa-user"></i> Account</a></li>
                <li class="divider"></li>
                <li><a href="../logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a></li>
            </ul>
        </li>
    </ul>

    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li><a href="index.php" class="active" style="color: #ffffff;"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a></li>

            <?php if($_SESSION['role'] == 'admin') { ?>
            <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#user" style="color: #ffffff;">
                    <i class="fa fa-fw fa-users"></i> Users <i class="fa fa-fw fa-caret-down"></i>
                </a>
                <ul id="user" class="collapse">
                    <li><a href="./users.php" style="color: #ffffff;">View All Users</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts" style="color: #ffffff;">
                    <i class="fa fa-fw fa-file-text"></i> My Account <i class="fa fa-fw fa-caret-down"></i>
                </a>
                <ul id="posts" class="collapse">
                    <li><a href="./viewprofile.php?name=<?php echo $_SESSION['username']; ?>" style="color: #ffffff;">View Profile</a></li>
                    <li><a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>" style="color: #ffffff;">Edit Profile</a></li>
                </ul>
            </li>
            <?php } else { ?>
            <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#user" style="color: #ffffff;">
                    <i class="fa fa-fw fa-users"></i> My Notes <i class="fa fa-fw fa-caret-down"></i>
                </a>
                <ul id="user" class="collapse">
                    <li><a href="./notes.php" style="color: #ffffff;">View All Notes</a></li>
                    <li><a href="./uploadnote.php" style="color: #ffffff;">Upload Note</a></li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts" style="color: #ffffff;">
                    <i class="fa fa-fw fa-file-text"></i> My Account <i class="fa fa-fw fa-caret-down"></i>
                </a>
                <ul id="posts" class="collapse">
                    <li><a href="./viewprofile.php?name=<?php echo $_SESSION['username']; ?>" style="color: #ffffff;">View Profile</a></li>
                    <li><a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>" style="color: #ffffff;">Edit Profile</a></li>
                </ul>
            </li>
            <?php } ?>
        </ul>
    </div>
</nav>

<style>
    /* Session name styling */
    .session-name {
        font-size: 1.2em; /* Adjust the font size */
        font-weight: bold; /* Make the font bold */
        color: red; /* Red color */
        margin-right: 5px; /* Add some right margin for spacing */
        text-transform: uppercase; /* Transform text to uppercase */
    }

    /* Custom CSS for navbar */
    .navbar-inverse {
        border-radius: 0;
    }

    .navbar-right {
        float: right !important;
        margin-right: 15px;
    }

    .navbar-nav > li > a {
        padding-top: 15px;
        padding-bottom: 15px;
    }

    .navbar-nav .dropdown-menu {
        background-color: #007bff;
        color: #ffffff;
    }

    .navbar-nav .dropdown-menu li a {
        color: #ffffff;
    }

    .navbar-nav .dropdown-menu li a:hover {
        background-color: #0056b3;
    }

    .navbar-nav .dropdown-menu .divider {
        background-color: #0056b3;
    }

    /* Side-nav styling */
    .side-nav {
        position: fixed;
        right: 0;
        top: 51px; /* Height of the navbar */
        width: 200px; /* Width of the side-nav */
        height: 100%;
        background-color: #007bff;
        color: #ffffff;
        padding-top: 20px;
    }

    .side-nav li {
        list-style: none;
        padding: 10px 15px;
    }

    .side-nav li a {
        color: #ffffff;
        display: block;
        text-decoration: none;
    }

    .side-nav li a:hover {
        background-color: #0056b3;
    }

    .side-nav .collapse {
        background-color: #007bff;
    }

    .side-nav .collapse li a {
        color: #ffffff;
        padding-left: 30px;
    }

    .side-nav .collapse li a:hover {
        background-color: #0056b3;
    }
</style>
