<?php include ('includes/connection.php'); ?>
<?php include('includes/adminheader.php');  ?>

<div id="wrapper">
    <?php include 'includes/adminnav.php';?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                <h1 class="page-header text-center">
                  Welcome 
                 <small class="welcome-text"><?php echo $_SESSION['name']; ?></small>
                  </h1>


                    <?php if($_SESSION['role'] == 'admin') { ?>
                    <h3 class="page-header text-center">
                        <marquee width="70%"><font color="green">BCA Notes uploaded by various users</font></marquee>
                    </h3>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <form action="" method="post">
                                    <table class="table table-bordered table-striped table-hover custom-table">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Description</th>
                                                <th>Type</th>
                                                <th>Uploaded on</th>
                                                <th>Uploaded by</th>
                                                <th>Status</th>
                                                <th>View</th>
                                                <th>Approve</th>
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $query = "SELECT * FROM uploads ORDER BY file_uploaded_on DESC";
                                            $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                            if (mysqli_num_rows($run_query) > 0) {
                                                while ($row = mysqli_fetch_array($run_query)) {
                                                    $file_id = $row['file_id'];
                                                    $file_name = $row['file_name'];
                                                    $file_description = $row['file_description'];
                                                    $file_type = $row['file_type'];
                                                    $file_date = $row['file_uploaded_on'];
                                                    $file_uploader = $row['file_uploader'];
                                                    $file_status = $row['status'];
                                                    $file = $row['file'];

                                                    echo "<tr>";
                                                    echo "<td class='table-text'>$file_name</td>";
                                                    echo "<td class='table-text'>$file_description</td>";
                                                    echo "<td class='table-text'>$file_type</td>";
                                                    echo "<td class='table-text'>$file_date</td>";
                                                    echo "<td class='table-text'><a href='viewprofile.php?name=$file_uploader' target='_blank'> $file_uploader </a></td>";
                                                    echo "<td class='table-text'>$file_status</td>";
                                                    echo "<td class='table-link'><a href='allfiles/$file' target='_blank' class='btn btn-success btn-sm'>View</a></td>";
                                                    
                                                    if ($file_status == 'approved') {
                                                        echo "<td><button class='btn btn-secondary btn-sm' disabled>Approved</button></td>";
                                                    } else {
                                                        echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to approve this note?')\" href='?approve=$file_id' class='btn btn-info btn-sm'>Approve</a></td>";
                                                    }
                                                    
                                                    echo "<td class='table-link'><a onClick=\"javascript: return confirm('Are you sure you want to delete this post?')\" href='?del=$file_id' class='btn btn-danger btn-sm'>Delete</a></td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php
                    if (isset($_GET['del'])) {
                        $note_del = mysqli_real_escape_string($conn, $_GET['del']);
                        $del_query = "DELETE FROM uploads WHERE file_id='$note_del'";
                        $run_del_query = mysqli_query($conn, $del_query) or die (mysqli_error($conn));
                        if (mysqli_affected_rows($conn) > 0) {
                            echo "<script>alert('Note deleted successfully'); window.location.href='index.php';</script>";
                        } else {
                            echo "<script>alert('An error occurred. Please try again!');</script>";
                        }
                    }

                    if (isset($_GET['approve'])) {
                        $note_approve = mysqli_real_escape_string($conn, $_GET['approve']);
                        $approve_query = "UPDATE uploads SET status='approved' WHERE file_id='$note_approve'";
                        $run_approve_query = mysqli_query($conn, $approve_query) or die (mysqli_error($conn));
                        if (mysqli_affected_rows($conn) > 0) {
                            echo "<script>alert('Note approved successfully'); window.location.href='index.php';</script>";
                        } else {
                            echo "<script>alert('An error occurred. Please try again!');</script>";
                        }
                    }
                    ?>
                    <?php } else { ?>
                    <h3 class="page-header text-center">
                        <marquee width="70%"><font color="green"><?php echo $_SESSION['course']; ?> </font><font color="brown"> notes uploaded by various users</font></marquee>
                    </h3>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <form action="" method="post">
                                    <table class="table table-bordered table-striped table-hover custom-table">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Description</th>
                                                <th>Type</th>
                                                <th>Uploaded by</th>
                                                <th>Uploaded on</th>
                                                <th>Download</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $currentusercourse = $_SESSION['course'];
                                            $query = "SELECT * FROM uploads WHERE file_uploaded_to = '$currentusercourse' AND status = 'approved' ORDER BY file_uploaded_on DESC";
                                            $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
                                            if (mysqli_num_rows($run_query) > 0) {
                                                while ($row = mysqli_fetch_array($run_query)) {
                                                    $file_id = $row['file_id'];
                                                    $file_name = $row['file_name'];
                                                    $file_description = $row['file_description'];
                                                    $file_type = $row['file_type'];
                                                    $file_date = $row['file_uploaded_on'];
                                                    $file = $row['file'];
                                                    $file_uploader = $row['file_uploader'];

                                                    echo "<tr>";
                                                    echo "<td class='table-text'>$file_name</td>";
                                                    echo "<td class='table-text'>$file_description</td>";
                                                    echo "<td class='table-text'>$file_type</td>";
                                                    echo "<td class='table-text'><a href='viewprofile.php?name=$file_uploader' target='_blank'> $file_uploader </a></td>";
                                                    echo "<td class='table-text'>$file_date</td>";
                                                    echo "<td class='table-link'><a href='allfiles/$file' target='_blank' class='btn btn-primary btn-sm'>Download</a></td>";
                                                    echo "</tr>";
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>

<style>
/* Custom CSS */
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');

body {
    font-family: 'Roboto', sans-serif;
    background-color: #f8f9fa;
}

.table th, .table td {
    text-align: center;
    vertical-align: middle;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    color: #343a40;
}

.table th {
    background-color: #343a40;
    color: white;
    border: 2px solid #dee2e6;
    font-weight: bold;
    font-size: 16px;
}

.table td {
    border: 2px solid #dee2e6;
    font-size: 14px;
}

.table-hover tbody tr:hover {
    background-color: #f1f1f1;
}

.page-header {
    margin-top: 20px;
    font-weight: bold;
    font-family: 'Roboto', sans-serif;
}

.btn {
    margin: 5px;
    font-family: 'Roboto', sans-serif;
}

.table-responsive {
    margin-top: 20px;
}

thead th {
    background: linear-gradient(to right, #4e73df, #224abe);
    color: #fff;
    border-bottom: 2px solid #dee2e6;
    font-size: 16px;
}

.table-bordered th,
.table-bordered td {
    border: 2px solid #dee2e6;
    font-size: 14px;
}

/* Additional Styles for Table Content */
.table-text {
    font-size: 14px;
    font-weight: 400;
}

.table-link a {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    font-size: 13px;
}

.table-link a:hover {
    text-decoration: underline;
}
.page-header {
    font-weight: bold; /* Make the "Welcome" text bold */
    color: blue;
    margin-bottom: 30px; /* Add some bottom margin for spacing */
    text-transform: uppercase; /* Transform text to uppercase */
    font-family: 'Arial', sans-serif; /* Change font family */
    letter-spacing: 1.5px; /* Increase spacing between letters */
    text-shadow: 2px 2px 5px rgba(0,0,0,0.3); /* Add a subtle shadow */
    transition: all 0.3s ease-in-out; /* Smooth transition for all properties */
}

/* Welcome text styling */
.welcome-text {
    font-size: 1.2em; /* Adjust the font size */
    color: blue; /* Blue color, adjust as needed */
    font-weight: bold; /* Make the text bold */
    display: block; /* Ensure the text is on a new line */
    margin-top: 10px; /* Add some top margin */
    transition: color 0.3s ease-in-out, transform 0.3s ease-in-out; /* Smooth transition for color and transform */
}

.welcome-text:hover {
    color: #0056b3; /* Change color on hover */
    transform: scale(1.1); /* Slightly increase size on hover */
}
