<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Notes Sharing</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,500" rel="stylesheet">
    <style>
           body {
    background-color: #2196F3; /* Blue background */
    font: 100% Roboto, sans-serif;
    text-align: center;
    background-image: url("images/index page.jpg");
    background-size: cover; /* Cover the entire background */
    background-position: center; /* Center the background image */
    padding: 50px;
    margin: 0;
}


        h1 {
            color: #ffffff; /* White text */
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        nav {
            width: 300px;
            background: white;
            color: rgba(0, 0, 0, 0.87);
            -webkit-clip-path: circle(24px at 30px 24px);
            clip-path: circle(24px at 32px 24px);
            -webkit-transition: -webkit-clip-path 0.5625s, clip-path 0.375s;
            transition: -webkit-clip-path 0.5625s, clip-path 0.375s;
            margin: 20px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        nav:hover {
            -webkit-transition-timing-function: ease-out;
            transition-timing-function: ease-out;
            -webkit-transition-duration: 0.75s;
            transition-duration: 0.75s;
            -webkit-clip-path: circle(390px at 225px 24px);
            clip-path: circle(390px at 150px 24px);
        }

        a {
            display: block;
            line-height: 50px;
            padding: 0 20px;
            color: inherit;
            text-decoration: none;
            font-weight: 500;
            font-size: 1.2em;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #ffe082; /* Light yellow on hover */
        }

        a:active {
            background-color: #ffca28; /* Darker yellow on active */
        }

        .navicon {
            display: inline-block;
            padding: 23px 20px;
            cursor: pointer;
            -webkit-transform-origin: 32px 24px;
            -ms-transform-origin: 32px 24px;
            transform-origin: 32px 24px;
        }

        .navicon div {
            position: relative;
            width: 20px;
            height: 2px;
            background: rgba(0, 0, 0, 0.87);
        }

        .navicon div:before,
        .navicon div:after {
            display: block;
            content: "";
            width: 20px;
            height: 2px;
            background: rgba(0, 0, 0, 0.87);
            position: absolute;
        }

        .navicon div:before {
            top: -7px;
        }

        .navicon div:after {
            top: 7px;
        }
    </style>
</head>
<body>
    <h1>G.F.G.C Sorab-BCA-Notes-Gallery</h1>
    <nav>
        <div class="navicon">
            <div></div>
        </div>
        <a href="login.php">Login</a>
        <a href="signup.php">Sign Up</a>
        <a href="dashboard/">Upload Notes</a>
    </nav>
</body>
</html>
