<?php include 'includes/connection.php'; ?>

<?php
session_start();
$error_message = "";

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['user']);
    $password = mysqli_real_escape_string($conn, $_POST['pass']);

    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $id = $row['id'];
            $user = $row['username'];
            $pass = $row['password'];
            $name = $row['name'];
            $email = $row['email'];
            $role = $row['role'];
            $course = $row['course'];

            if (password_verify($password, $pass)) {
                $_SESSION['id'] = $id;
                $_SESSION['username'] = $username;
                $_SESSION['name'] = $name;
                $_SESSION['email'] = $email;
                $_SESSION['role'] = $role;
                $_SESSION['course'] = $course;
                header('location: dashboard/');
                exit();
            } else {
                $error_message = "Invalid password. Please try again.";
            }
        }
    } else {
        $error_message = "Username doesn't exist. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,500" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5f5; /* Light gray background */
            background-image: url("images/login page.jpg");
            background-size: cover;
            font-family: 'Roboto', sans-serif;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-card {
            width: 300px;
            background: #ffffff; /* White background */
            color: #333333; /* Dark text color */
            margin: 20px;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }

        .login-card:hover {
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: #2196F3; /* Blue text */
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-bottom: 2px solid #cccccc; /* Light gray bottom border */
            font-size: 1em;
            transition: border-bottom 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-bottom: 2px solid #2196F3; /* Blue bottom border on focus */
        }

        input[type="submit"] {
            background-color: #2196F3; /* Blue background */
            color: #ffffff; /* White text */
            cursor: pointer;
            border: none;
            border-radius: 5px;
            font-size: 1.2em;
            padding: 12px 0;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #0d8bf2; /* Darker blue on hover */
        }

        .login-help {
            margin-top: 15px;
            font-size: 0.9em;
            color: #666666; /* Gray text */
        }

        .login-help a {
            color: #2196F3; /* Blue links */
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .login-help a:hover {
            color: #0d8bf2; /* Darker blue on hover */
        }

        .error-message {
            color: #ff0000; /* Red error message */
            font-size: 0.9em;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>Log-in</h1>
        <?php
        if (!empty($error_message)) {
            echo '<div class="error-message">' . $error_message . '</div>';
        }
        ?>
        <form method="POST">
            <input type="text" name="user" placeholder="Username" required="">
            <br><br>
            <input type="password" name="pass" placeholder="Password" required="">
            <br><br>
            <input type="submit" name="login" class="login login-submit" value="Login">
        </form>
        
        <div class="login-help">
            <a href="signup.php">Register</a> • <a href="recoverpassword.php">Forgot Password</a>
        </div>
    </div>
</body>
</html>
